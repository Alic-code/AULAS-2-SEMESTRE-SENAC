<?php
    session_start();
    
    $usuario = $_POST["user"] ;
    $senha = $_POST["pass"];
    
    $usuarioCorreto = "admin";
    $senhaCorreta = "123";

    if(($usuario == $usuarioCorreto) && ($senha == $senhaCorreta))(
        $_SESSION("logado") = true;
    )
?>
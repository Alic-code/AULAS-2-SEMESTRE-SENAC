<?php
// 1. Defina a função com o nome correto
function maior_Numero($n1, $n2, $n3) {
    // 2. Use o return para que o valor saia da função e vá para o HTML
    return max($n1, $n2, $n3);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Resultado do Maior Número</title>
</head>
<body>
    <h1>Resultado: <?= maior_Numero(3.5, 50, 15); ?></h1>
</body>
</html>
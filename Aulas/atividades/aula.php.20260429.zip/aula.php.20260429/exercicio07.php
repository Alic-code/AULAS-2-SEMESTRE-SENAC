<?php

$resultado = ""; // <- IMPORTANTE

function temTamanhoMinimo($senha) {
    return strlen($senha) >= 8;
}

function temNumero($senha) {
    for ($i = 0; $i < strlen($senha); $i++) {
        if (is_numeric($senha[$i])) {
            return true;
        }
    }
    return false;
}

function temMaiuscula($senha) {
    for ($i = 0; $i < strlen($senha); $i++) {
        if (ctype_upper($senha[$i])) {
            return true;
        }
    }
    return false;
}

function senhaValida($senha) {
    return temTamanhoMinimo($senha) &&
           temNumero($senha) &&
           temMaiuscula($senha);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $senha = $_POST["senha"];

    if (senhaValida($senha)) {
        $resultado = "Senha válida!";
    } else {
        $resultado = "Senha inválida!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Validação de Senha</title>
</head>
<body>

    <h2>Validação de Senha Segura</h2>

    <form method="POST">
        <label>Digite a senha:</label><br>
        <input type="text" name="senha" required><br><br>
        <button type="submit">Validar</button>
    </form>

    <p><?php echo $resultado; ?></p>

</body>
</html>
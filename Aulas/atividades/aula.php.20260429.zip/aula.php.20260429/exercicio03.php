<?php
    function somar (int $a, int $b) : int {
    return  $a + $b; 
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    Resultado: <?=somar(3.5,6);?>
</body>
</html>
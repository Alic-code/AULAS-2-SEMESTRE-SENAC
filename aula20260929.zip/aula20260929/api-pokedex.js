const pokeInput = document.getElementById('pokeInput');
const searchBtn = document.getElementById('searchBtn');
const loadingMsg = document.getElementById('loadingMsg');
const errorMsg = document.getElementById('errorMsg');
const pokemonCard = document.getElementById('pokemonCard');

const pokeNameEl = document.getElementById('pokeName');
const pokeIdEl = document.getElementById('pokeId');
const pokeImageEl = document.getElementById('pokeImage');
const pokeTypesEl = document.getElementById('pokeTypes');
const pokeHeightEl = document.getElementById('pokeHeight');
const pokeWeightEl = document.getElementById('pokeWeight');

searchBtn.addEventListener('click', searchPokemon);

// Permite pesquisar ao premir a tecla "Enter"
pokeInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        searchPokemon();
    }
});

async function searchPokemon() {
    // Obter o valor introduzido pelo utilizador e formatá-lo (remover espaços e colocar em minúsculas)
    const query = pokeInput.value.trim().toLowerCase();
    
    if (!query) return;

    // Reset da interface: mostrar carregamento, ocultar erro e cartão
    errorMsg.style.display = 'none';
    pokemonCard.style.display = 'none';
    loadingMsg.style.display = 'block';

    try {
        // Requisição à PokéAPI
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${query}`);
        
        // Tratamento de erros: se não encontrar (ex: 404) ou falhar
        if (!response.ok) {
            if (response.status === 404) {
                throw new Error('Pokémon não encontrado. Verifique o nome ou número.');
            }
            throw new Error('Ocorreu um erro na requisição à API.');
        }

        const data = await response.json();

        // Popular os dados no ecrã
        pokeNameEl.textContent = data.name;
        pokeIdEl.textContent = `#${data.id}`;
        
        // Obter a imagem (sprite)
        pokeImageEl.src = data.sprites.front_default || '';

        // Obter e formatar os tipos
        pokeTypesEl.innerHTML = '';
        data.types.forEach(typeInfo => {
            const span = document.createElement('span');
            span.className = 'type-badge';
            span.textContent = typeInfo.type.name;
            
            // Simples lógica de cor (opcional, baseada na imagem que mostra amarelo para electric)
            if (typeInfo.type.name === 'electric') {
                span.style.backgroundColor = '#ffca3a';
            } else {
                span.style.backgroundColor = '#e9ecef';
            }
            
            pokeTypesEl.appendChild(span);
        });

        // A API devolve altura em decímetros e peso em hectogramas. 
        // É necessário converter para metros e quilogramas.
        const heightInMeters = (data.height / 10).toFixed(1);
        const weightInKg = (data.weight / 10).toFixed(1);

        pokeHeightEl.textContent = heightInMeters;
        pokeWeightEl.textContent = weightInKg;

        // Ocultar carregamento e mostrar o cartão
        loadingMsg.style.display = 'none';
        pokemonCard.style.display = 'block';

    } catch (error) {
        // Em caso de erro, ocultar carregamento e exibir mensagem de erro
        loadingMsg.style.display = 'none';
        errorMsg.textContent = error.message;
        errorMsg.style.display = 'block';
    }
}
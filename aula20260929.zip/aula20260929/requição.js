const listaPosts = document.getElementById("lista-posts");
const mensagemErro = document.getElementById("erro");

const url = "https://jsonplaceholder.typicode.com/posts?_limit=5";

fetch(url)
    .then(response => {
        // Verifica se a requisição deu certo
        if (!response.ok) {
            throw new Error("Erro ao buscar os posts.");
        }

        return response.json();
    })
    .then(posts => {
        // Limpa a mensagem "Carregando..."
        listaPosts.innerHTML = "";

        // Percorre os 5 posts
        posts.forEach(post => {
            const li = document.createElement("li");

            li.textContent = post.title;

            listaPosts.appendChild(li);
        });
    })
    .catch(error => {
        // Trata erros da requisição
        listaPosts.innerHTML = "";
        mensagemErro.textContent = "Não foi possível carregar os posts.";
        console.error(error);
    });

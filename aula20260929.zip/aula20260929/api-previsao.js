// Referências aos elementos do DOM
const cityInput = document.getElementById('cityInput');
const searchBtn = document.getElementById('searchBtn');
const errorMsg = document.getElementById('errorMsg');
const weatherCard = document.getElementById('weatherCard');

const cityNameEl = document.getElementById('cityName');
const temperatureEl = document.getElementById('temperature');
const apparentTempEl = document.getElementById('apparentTemp');
const conditionEl = document.getElementById('condition');
const humidityEl = document.getElementById('humidity');
const weatherIconEl = document.getElementById('weatherIcon');

// Dicionário para traduzir os códigos WMO da API para descrições em Português
const weatherCodes = {
    0: { desc: 'Céu limpo', icon: '☀️' },
    1: { desc: 'Maioritariamente limpo', icon: '🌤️' },
    2: { desc: 'Parcialmente nublado', icon: '⛅' },
    3: { desc: 'Encoberto', icon: '☁️' },
    45: { desc: 'Nevoeiro', icon: '🌫️' },
    48: { desc: 'Nevoeiro', icon: '🌫️' },
    51: { desc: 'Chuvisco ligeiro', icon: '🌦️' },
    53: { desc: 'Chuvisco moderado', icon: '🌧️' },
    55: { desc: 'Chuvisco forte', icon: '🌧️' },
    61: { desc: 'Chuva ligeira', icon: '🌧️' },
    63: { desc: 'Chuva moderada', icon: '🌧️' },
    65: { desc: 'Chuva forte', icon: '🌧️' },
    71: { desc: 'Neve ligeira', icon: '🌨️' },
    73: { desc: 'Neve moderada', icon: '🌨️' },
    75: { desc: 'Neve forte', icon: '❄️' },
    95: { desc: 'Trovoada', icon: '⛈️' }
};

searchBtn.addEventListener('click', async () => {
    const city = cityInput.value.trim();
    if (!city) return;

    // Limpar estado anterior no ecrã
    errorMsg.style.display = 'none';
    weatherCard.style.display = 'none';

    try {
        // 1. Requisição de Geocodificação (Obter coordenadas da cidade)
        const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=pt`;
        const geoResponse = await fetch(geoUrl);
        
        if (!geoResponse.ok) {
            throw new Error('Falha na comunicação com o servidor de geocodificação.');
        }
        
        const geoData = await geoResponse.json();

        // Tratamento de erro: Cidade não encontrada
        if (!geoData.results || geoData.results.length === 0) {
            throw new Error('Cidade não encontrada. Tente outro nome.');
        }

        const location = geoData.results[0];
        const lat = location.latitude;
        const lon = location.longitude;
        // Tenta mostrar o estado/distrito se existir, caso contrário o país
        const locationName = `${location.name} - ${location.admin1 || location.country}`;

        // 2. Requisição do Estado do Tempo usando as coordenadas obtidas
        const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code`;
        const weatherResponse = await fetch(weatherUrl);
        
        if (!weatherResponse.ok) {
            throw new Error('Falha ao obter os dados meteorológicos.');
        }

        const weatherData = await weatherResponse.json();
        const current = weatherData.current;

        // Mapear o código do tempo para texto e ícone
        const weatherCodeInfo = weatherCodes[current.weather_code] || { desc: 'Desconhecido', icon: '❓' };

        // 3. Exibir os dados no ecrã
        cityNameEl.textContent = locationName;
        temperatureEl.textContent = current.temperature_2m;
        apparentTempEl.textContent = current.apparent_temperature;
        humidityEl.textContent = current.relative_humidity_2m;
        conditionEl.textContent = weatherCodeInfo.desc;
        weatherIconEl.textContent = weatherCodeInfo.icon;

        // Mostrar o cartão
        weatherCard.style.display = 'block';

    } catch (error) {
        // Mostrar erro no ecrã (cidade não encontrada, falha na requisição, etc.)
        errorMsg.textContent = error.message;
        errorMsg.style.display = 'block';
    }
});
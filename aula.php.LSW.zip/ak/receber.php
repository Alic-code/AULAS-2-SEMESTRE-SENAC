<?php
    $user = $_POST["user"];
    $pass = $_POST["pass"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
      
    <p>Usuario: <?php echo $user ?></p>
    <p>Senha: <?php echo $pass ?></p>  
</body>
</html>
<?php
    $nomeArquivo = $_FILES["file"]["name"];
    $tipoArquivo = $_FILES["file"]["type"];
    $sizeArquivo = $_FILES["file"]["size"];
    $tmpArquivo = $_FILES["file"]["tmp_name"];
    $errArquivo = $_FILES["file"]["error"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <b> Nome arquivo: </b>
    <?= $nomeArquivo; ?>
    <br>
    <b> tipo do arquivo: </b>
    <?= $tipoArquivo; ?>
    <b> tamanho do arquivo: </b>
    <?= $sizeArquivo; ?>
    <b> temporario do arquivo: </b>
    <?= $tmpArquivo; ?>
    <b> erro do arquivo: </b>
    <?= $errArquivo; ?>
    
    
</body>
</html>
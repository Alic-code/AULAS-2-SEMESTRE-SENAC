<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form action="upload.php" method="post" enctype="multipart/form-data">
        <div>
            <label>Escolha um arquivo:</label><br><br>
            <input type="file" name="file"><br><br>
        </div> 
        
        <button type="submit">Enviar</button>

    </form>
    
</body>
</html>
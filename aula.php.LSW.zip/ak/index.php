<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        
    *{
    box-sizing: border-box;
    }

    body{
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #4facfe, #00f2fe);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0;
    }

    form{
    background: white;
    padding: 30px;
    border-radius: 10px;
    width: 300px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }

    input{
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    }

    button{
    width: 100%;
    padding: 10px;
    background: #19578dff;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
    }

    button:hover{
    background: #2f80ed;
    }
    </style>    
</head>
<body>
    <form action="tab.php" method="POST">
        <div>
            <h2>Login</h2>

            <label>insira a tabuada:</label>
            <input type="text" name="n" id="n">
        </div> 
        
        <button type="submit">Enviar</button>

    </form>
</body>
</html>